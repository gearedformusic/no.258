This balloon mimics the text boxes from Pokemon Red/Blue and Pokemon Diamond/Pearl. The main character gets the RB balloons and the side character gets the DP ones. The DP balloon is based on the Panel 1 design in Pearl for text boxes.

Works best if you have the Pokemon Gameboy font, Pokemon GB.ttf, and the Diamond/Pearl font, Pokemon DPPt.ttf. It should be legible either way though. The two fonts are included with the balloon, so you can just install them from the z_bluepearl directory if you don't already have them.


Made by Zarla for Radic and Farnsworth.

http://www.ashido.com/nplu/ghost/
